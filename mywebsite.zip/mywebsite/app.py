from flask import Flask, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

app = Flask(__name__)
app.secret_key = 'my-secret-key'  # Change this in real apps
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'

# Initialize database and login manager
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)

# User model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)

# Load user from session
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Home page
@app.route('/')
def home():
    if current_user.is_authenticated:
        return f"<h1>Welcome, {current_user.username}!</h1><a href='/logout'>Logout</a> | <a href='/profile'>Profile</a>"
    return "<h1>Welcome to the site</h1><a href='/login'>Login</a> | <a href='/signup'>Signup</a>"

# Signup
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            return "Username already exists. Try another."
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return '''
    <h2>Signup</h2>
    <form method="post">
        Username: <input name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Sign Up">
    </form>
    '''

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username'], password=request.form['password']).first()
        if user:
            login_user(user)
            return redirect(url_for('home'))
        return "Invalid username or password."
    return '''
    <h2>Login</h2>
    <form method="post">
        Username: <input name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Log In">
    </form>
    '''

# Profile page
@app.route('/profile')
@login_required
def profile():
    return f"<h2>Your Profile</h2><p>Username: {current_user.username}</p><a href='/'>Home</a>"

# Logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

# Run the app
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000)
from flask import Flask
app = Flask(__name__)

@app.route('/')
def home():
    return '''
    <h1>HI MOTHER FUCKER</h1>
    <p>This website is running from Termux on Android.</p>
    '''

@app.route('/about')
def about():
    return '<h2>About Page</h2><p>This is a simple site hosted with Flask in Termux.</p>'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
